#include <iostream>
using namespace std;

int main() {
	string nome, data;
	string texto = " esteve aqui em ";
	cout << "Nome: ";
	cin >> nome;
	cout << "Data: ";
	cin >> data;
	cout << nome << texto << data;
}
