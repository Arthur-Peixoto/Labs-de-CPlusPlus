#include <cctype>
#include <iostream>
using namespace std;

void FirstName(const char* str, char* stri);
void LastName(const char* str, char* stri);


int main()
{
    char destinoum = ' ';
    char  destinodois{' '};
    char origem[40]{};
    bool test{};
    cout << "Entre com os nomes a cadastrar (�.� para encerrar):" << endl;
    cin.getline(origem, 40);
    while (origem != ".") {
        FirstName(origem, &destinoum);
        LastName(origem, &destinodois);
        cout << destinodois << "," << destinoum << endl;

    }
}

void FirstName(const char* str, char* stri)
{
     while (*str != ' ' && *str) {
       *stri = *str;
       str++;
       stri++;
      }
}

void LastName(const char* str, char* stri)
{
    int cont{};
    while (*str) {
        while (*str != ' ' && *str) {
            *stri = *str;
            str++;
            stri++;
        }
        cont++;
        ++str;
    }
}
