#include <iostream>
#include <cctype>
using namespace std;

int Frase(const char* str);

int main()
{
    cout << "Entre com uma frase :" << endl;
    char frase[40]{};
    cin.getline(frase, 40);

    int retorna = Frase(frase);

    cout << "Existem " << retorna << " palavras nesta frase!";


}

int Frase(const char* str)
{
    int cont{};
    const char* retornar{};
    while (*str) {
        while (*str != ' ' && *str) {
            ++str;
        }
        cont++;
        ++str;
    }
    return cont;
}
