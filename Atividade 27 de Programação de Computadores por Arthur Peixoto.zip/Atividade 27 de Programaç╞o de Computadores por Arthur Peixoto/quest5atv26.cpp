using namespace std;
#include <iostream>

struct Charset
{
	char* str; // ponteiro para vetor din�mico
	int tam; // tamanho do vetor
};
void Atribuir(Charset);
void Exibir(Charset);
int Retornartam(Charset);
void Concatenar(Charset);



int main()
{
	Charset carac;
	strcpy(carac.str, "Vasco");
	carac.tam = strlen(carac.str);

	 Atribuir(carac);
	 Exibir(carac);
	 int retorna;
	 retorna = Retornartam(carac);
	 Concatenar(carac);
}

void Atribuir(Charset* st) {
	const char* stringg = "Vasco X";
	*st->str = *stringg;
}
void Exibir(Charset* st) {
	cout << *st->str;
}
int Retornartam(Charset *st){
	int x;
	x = st->tam;
	return x;
}
void Concatenar(Charset* st) {
	const char* strin = "Flamengo";
	strcat(st->str, strin);
}