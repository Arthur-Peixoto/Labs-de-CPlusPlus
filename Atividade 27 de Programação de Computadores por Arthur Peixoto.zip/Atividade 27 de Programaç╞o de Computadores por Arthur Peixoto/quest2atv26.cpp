#include <iostream>
#include <cctype>
using namespace std;

bool Nomecompleto(const char* str);

int main()
{
    char frase[40]{};
    bool test{};
    cin.getline(frase, 40);
    cout << "Entre com os nomes dos aprovados(fim para encerrar) :" << endl;
    while (frase != "fim") {
        Nomecompleto(frase);
        if (test == true) {
            cout << "\t<-- Corrigido";
        }
        else if (test == false) {
            cout << "\t<-- OK";
        }
    }
}

bool Nomecompleto(const char* str)
{
    int cont{};
    bool teste{};
    int i{};
    while (*str) {
        while (str[i] != ' ') {
            cont = 0;
            if (i == 0) {
                char(islower(str[i]) ? str[i] : toupper(str[i]) && (teste == true));
            }
            else {
                char(isupper(str[i]) ? str[i] : tolower(str[i]) && (teste == true));
            }
            cout << str[i];
            ++cont;
            i++;
        }
        if (cont >= 2) {
            char(isupper(str[i - 1]) ? str[i - 1] : tolower(str[i - 1]) && (teste == false));
            char(isupper(str[i - 2]) ? str[i - 2] : tolower(str[i - 2]));
        }
        cout << " ";
        i++;
    }
    return teste;
}