double angulo(double x, double y);
double calculo(double a, double b);