#include <iostream>
using namespace std;

int main() {
	char ch{};
	int x{}, idade{}, num{}, peso{}, altura{};
	//a)
	ch != 'q' && ch != 'k';
	//b
	idade > 15 && idade < 26;
	//c
	x % 2 != 0 && x > 30;
	//d
	num % 5 == 0 || num % 8 == 0;
	//e
	peso < 50 && altura > 160;
}