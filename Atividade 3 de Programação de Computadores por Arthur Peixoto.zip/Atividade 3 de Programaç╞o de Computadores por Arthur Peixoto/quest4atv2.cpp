#include <iostream>
using namespace std;

int main(int argc, char ** argv)
{
	cout << "Estou Aprendendo " << argv[1] << " " << argv[3] << endl;

    return 0;
}