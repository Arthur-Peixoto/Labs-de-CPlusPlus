#include <iostream>
using namespace std;

int main()
{
	cout << "C\n\t+\n\t\t+" << endl;
	
	return 0;
}