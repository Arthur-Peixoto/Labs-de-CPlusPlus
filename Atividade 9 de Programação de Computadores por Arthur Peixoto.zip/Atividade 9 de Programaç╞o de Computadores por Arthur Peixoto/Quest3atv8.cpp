#include <iostream>
using namespace std;

float x1, x2, x3, x4, x5;

int main() {
	x1 = 1.89592589;
	x2 = 1.421374167;
	x3 = 1.400000000001;
	x4 = 1.545454545445;
	x5 = 1.1111111141;
	cout << fixed;
	cout.precision(8);
	cout << "valor 1: " << x1 << " valor 2: " << x2 << " valor 3: " << x3 << " valor 4: " << x4 << " valor 5: " << x5;
}